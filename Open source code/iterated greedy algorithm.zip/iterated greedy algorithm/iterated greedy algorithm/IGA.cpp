#include <stdio.h>
#include <iostream>
#include <vector>
#include <ctime>
#include <fstream>
#include <string>
#include <math.h>
#include <queue>


using namespace std;
vector<vector<int>> data;
vector<vector<pair<int, int>>> flowshop;
struct job
{
	int index;//index
	int tpt;//total processing time
};
int N = 0;
int M = 0;
int d = 4;//destruction size
double T = 0.4;
int Termination = 5000;
string txt = "VFR20_10_1_Gap.txt";
void readData();
vector<int> Initialization();
vector<int> LocalSearch(vector<int> pi);
int Obj(vector<int> pi);
vector<int> insertItoJ(vector<int>& pi, int i, int j);
vector<int> DC(vector<int> pi);
bool Acceptance(int obj, int obj2);
bool comp(job i, job j);
int main()
{
	readData();
	srand((unsigned)time(NULL));

	int count = 0;//iteration index
	int Pi0Obj = 0;
	int PiObj = 0;
	int Pi1Obj = 0;
	int Pi2Obj = 0;
	int PiBestObj = 0;
	vector<int> pi0 = Initialization();//Initialization phase
	Pi0Obj = Obj(pi0);
	cout << Pi0Obj << endl;
	vector<int> pi = LocalSearch(pi0);//Local search phase
	PiObj = Obj(pi);
	cout << PiObj << endl;
	vector<int> piBest = pi;//best solution
	PiBestObj = PiObj;
	while (count < 5000)
	{
		count++;
		int k = 1;
		vector<int> pi1 = DC(pi);//Destruction and construction phases
		Pi1Obj = Obj(pi1);
		vector<int> pi2 = LocalSearch(pi1);//Local search phase
		Pi2Obj = Obj(pi2);
		if (Pi2Obj < PiObj)
		{
			pi = pi2;
			PiObj = Pi2Obj;
			if (PiObj < PiBestObj)
			{
				piBest = pi;
				PiBestObj = PiObj;
			}
		}
		else
		{
			if (Acceptance(PiObj, Pi2Obj))//acceptance criterion
			{
				pi = pi2;
				PiObj = Pi2Obj;
			}
		}
		cout << "iteration:" << count << "," << PiObj << "," << Pi2Obj << "," << PiBestObj << endl;

	}
	system("pause");

#pragma endregion
	return 0;
}
int Obj(vector<int> pi)//calculate makespan
{
	int obj = 0;
	flowshop[0][0].second = data[pi[0]][0];//the first job on the first machine
	for (int i = 1; i < pi.size(); ++i)// the jobs on the first machine
	{
		flowshop[0][i].first = flowshop[0][i - 1].second;
		flowshop[0][i].second = flowshop[0][i].first + data[pi[i]][0];
	}

	for (int j = 1; j < M; ++j)//the jobs on other machines
	{
		//the first job on other machines
		flowshop[j][0].first = flowshop[j - 1][0].second;
		flowshop[j][0].second = flowshop[j][0].first + data[pi[0]][j];
		//other jobs on other machines
		for (int i = 1; i < pi.size(); ++i)
		{
			flowshop[j][i].first = max(flowshop[j - 1][i].second, flowshop[j][i - 1].second);
			flowshop[j][i].second = flowshop[j][i].first + data[pi[i]][j];
		}
	}
	obj = flowshop[M - 1][pi.size() - 1].second;
	return obj;
}
void readData()
{
	string filename = txt;
	ifstream f(filename, ios::in);

	if (!f) {
		cerr << "No such a file:" << filename << endl;
		throw(1);
	}

	f >> N >> M;
	int m;
	int pt; //processing time
	for (int i = 0; i < N; ++i)
	{
		vector<int> vec_pt;
		for (int j = 0; j < M; ++j)
		{
			f >> m >> pt;
			vec_pt.push_back(pt);
		}
		data.push_back(vec_pt);
	}

	for (int j = 0; j < M; ++j)
	{
		vector<pair<int, int>> vec;
		for (int i = 0; i < N; ++i)
		{
			vec.push_back(make_pair(0, 0));
		}
		flowshop.push_back(vec);
	}
}
vector<int> Initialization()
{
	vector<job> vec_job;//total processing time
	for (int i = 0; i < N; ++i)
	{
		int tpt = 0;
		for (int j = 0; j < M; ++j)
		{
			tpt += data[i][j];
		}
		job _j = { i, tpt };

		vec_job.push_back(_j);
	}

	sort(vec_job.begin(), vec_job.end(), comp);

	vector<int> pi;
	pi.push_back(vec_job[0].index);

	for (int i = 1; i < N; ++i)
	{
		int bestObj = INT_MAX;
		int bestP = -1;
		for (int j = 0; j < pi.size() + 1; ++j)
		{
			vector<int> tempPi = pi;
			tempPi.insert(tempPi.begin() + j, vec_job[i].index);
			int obj = Obj(tempPi);
			if (obj < bestObj)
			{
				bestObj = obj;
				bestP = j;
			}
		}
		pi.insert(pi.begin() + bestP, vec_job[i].index);
	}
	int obj = Obj(pi);
	return pi;
}
bool comp(job i, job j)
{
	return i.tpt > j.tpt;
}
vector<int> LocalSearch(vector<int> pi)
{
	vector<int> pi1;
	bool iffind = false;
	do
	{
		iffind = false;
		for (int i = 0; i < N; ++i)
		{
			for (int j = 0; j <= N; ++j)
			{
				pi1 = insertItoJ(pi, i, j);
				if (Obj(pi1) < Obj(pi))
				{
					pi = pi1;
					iffind = true;
				}
			}
		}
	} while (iffind);

	return pi1;
}



//destruction and construction
vector<int> DC(vector<int> pi)
{
	//destruction
	vector<int> piR;
	for (int i = 0; i < d; i++)//randomly select d elements
	{
		int r = rand() % pi.size();
		piR.push_back(*(pi.begin() + r));
		pi.erase(pi.begin() + r);
	}
	//construction
	for (int i = 0; i < piR.size(); i++)
	{
		int bestObj = INT_MAX;
		int bestP = -1;
		for (int j = 0; j < pi.size() + 1; ++j)
		{
			vector<int> tempPi = pi;
			tempPi.insert(tempPi.begin() + j, piR[i]);
			int obj = Obj(tempPi);
			if (obj < bestObj)
			{
				bestObj = obj;
				bestP = j;
			}
		}
		pi.insert(pi.begin() + bestP, piR[i]);
	}
	return pi;
}

bool Acceptance(int obj, int obj2)
{
	int tpt = 0;
	for (int i = 0; i < N; ++i)
	{
		for (int j = 0; j < M; ++j)
		{
			tpt += data[i][j];
		}
	}

	double temperature = double(T*tpt / (10 * M*N));
	double r = rand() / double(RAND_MAX);
	double probability = exp(-(obj2 - obj) / temperature);
	if (r < probability)
	{
		if (obj != obj2)
			cout << "accepted" << endl;
		return true;
	}
	else
	{
		return false;
	}
}
//insert i into position j
vector<int> insertItoJ(vector<int>& pi, int i, int j)
{
	vector<int> pi1;
	for (int k = 0; k < j; k++)
	{
		if (k != i)
		{
			pi1.push_back(pi[k]);
		}
	}
	pi1.push_back(pi[i]);
	for (int k = j; k < pi.size(); k++)
	{
		if (k != i)
		{
			pi1.push_back(pi[k]);
		}
	}
	return pi1;
}